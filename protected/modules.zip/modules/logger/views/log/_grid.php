<?php
use app\components\TGridView;
use app\models\User;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\Pjax;
/**
 *
 * @var yii\web\View $this
 * @var yii\data\ActiveDataProvider $dataProvider
 * @var app\models\search\Log $searchModel
 */

?>


<?php echo Html::a('','#',['class'=>'multiple-delete glyphicon glyphicon-trash','id'=>"bulk-delete"])?>

<?php

Pjax::begin([
    'id' => 'log-pjax-grid','enablePushState'=>false,'enableReplaceState'=>false
]);
echo TGridView::widget([
    'id' => 'log-grid-view',
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'tableOptions' => [
        'class' => 'table table-bordered'
    ],
    'columns' => [
        [
            'name' => 'check',
            'class' => 'yii\grid\CheckboxColumn',
            'visible' => User::isAdmin()
        ],
        // ['class' => 'yii\grid\SerialColumn','header'=>'<a>S.No.<a/>'],

        'id',
        'error',
            /* 'api:html',*/
            /* 'description:html',*/
            [
            'attribute' => 'state_id',
            'format' => 'raw',
            'filter' => isset($searchModel) ? $searchModel->getStateOptions() : null,
            'value' => function ($data) {
                return $data->getStateBadge();
            }
        ],
        'link',
        'created_on:datetime',

        [
            'class' => 'app\components\TActionColumn',
            'template' => '{view} {delete}',
            'header' => '<a>Actions</a>'
        ]
    ]
]);
?>
<?php Pjax::end(); ?>

<script>
$('#bulk-delete').click(function(e){
	
	e.preventDefault();
	 var keys = $('#log-grid-view').yiiGridView('getSelectedRows');

	 if ( keys != '' ){

		 var url = '<?php echo Url::toRoute(['log/mass','action'=>'delete']);?>';
		 
		 var ok = confirm("Do you really want to delete these items?");

			if( ok ) {
        	     $.ajax({
        			url  : url,
        			type : "POST",
        			data : {"ids" : keys},
        			success : function( response ){
        				if ( response.status == "OK" ){
        					 $("#error_flash").show();
        					 
        					 $.pjax.reload({container: '#log-pjax-grid'});
        				}else{ 
        					 $("#error_flash").hide();
        				}
        			}
        	     });
			}
		 
	 }else{
		
		alert('Please select items to delete');
	 }
	 
});
</script>
