<?php
use app\components\useraction\UserAction;

/* @var $this yii\web\View */

/* $this->title = $model->label() .' : ' . $model->id; */
$this->params['breadcrumbs'][] = [
    'label' => Yii::t('app', 'Logs'),
    'url' => [
        'index'
    ]
];
$this->params['breadcrumbs'][] = (string) $model;
?>

<div class="wrapper">
	<div class=" panel ">

		<div class="log-view panel-body">
			<?php

echo \app\components\PageHeader::widget([
    'model' => $model
]);
?>



		</div>
	</div>
<div class="panel">
	<div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-bg">
                    <div class="panel-body">
                        <?php
    
                     echo \app\components\TDetailView::widget([
        'id' => 'log-detail-view',
        'model' => $model,
        'options' => [
            'class' => 'table table-bordered table-striped'
        ],
        'attributes' => [
            'id',
            'error',
            'api:html',
            /*'description:html',*/
            [
                'attribute' => 'state_id',
                'format' => 'raw',
                'value' => $model->getStateBadge()
            ],
            'link',
            [
                'attribute' => 'type_id',
                'value' => $model->getType()
            ],
            'created_on:datetime'
            /*
         * [
         * 'attribute' => 'created_by_id',
         * 'format'=>'raw',
         * 'value' => $model->getRelatedDataLink('created_by_id'),
         * ],
         */
        ]
                ])?>
                    </div>
                </div>
                 
            </div>
            <div class="col-md-6">
                <div class="panel panel-bg">
                    <div class="panel-body">
                    <div class="description">
                    <?php

                        echo nl2br($model->description);
                        ?>
                    </div>
                </div>
                 </div>
            </div>
        </div>
   




 			
		</div>
        <div class="panel-body">
            <div>
        <?php

echo UserAction::widget([
    'model' => $model,
    'attribute' => 'state_id',
    'states' => $model->getStateOptions()
]);
?>

        </div>
        </div>
	</div>

</div>