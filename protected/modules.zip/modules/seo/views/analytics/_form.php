<?php
use yii\helpers\Html;
use app\components\TActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\seo\models\Analytics */
/* @var $form yii\widgets\ActiveForm */
?>
<header class="card-header">
                            <?php echo strtoupper(Yii::$app->controller->action->id); ?>
                        </header>
<div class="card-body">

    <?php
    $form = TActiveForm::begin([
       // 'layout' => 'horizontal',
        'id' => 'analytics-form'
    ]);
    
    echo $form->errorSummary($model);
    ?>
    
    <div class="col-sm-6 offset-sm-3">
    	<?php echo $form->field($model, 'type_id')->dropDownList($model->getTypeOptions(), ['prompt' => '']) ?>
    
		 <?php echo $form->field($model, 'account')->textInput(['maxlength' => 512]) ?>

		 <?php echo $form->field($model, 'domain_name')->textInput(['maxlength' => 512]) ?>

		 <?php //echo $form->field($model, 'additional_information')->textInput(['maxlength' => 512]) ?>


	   <div class="row">
		<div
			class="col-md-12 bottom-admin-button btn-space-bottom text-right">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Save') : Yii::t('app', 'Update'), ['id'=> 'analytics-form-submit','class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>
    </div>
	</div>

    <?php TActiveForm::end(); ?>

</div>
