<?php
use yii\helpers\Url;
?>

<li class="<?=$class?> nav-item dropdown " id="<?=$id?>"><a class="mega-link nav-link dropdown-toggle text-muted waves-effect waves-dark color-bell"
	data-toggle="dropdown" href="javascript:;" > <span
		class="mega-icon"><i class="fa fa-bell"></i></span><sup><span
		class="badge  badge-danger notiCount-<?=$id?>"><?=$count?></span></sup>
</a>
<div class="dropdown-menu mailbox animated bounceInDown">
	<ul
		class=" notification-dropdown  notification-menu-container ">
		<li>
			<div class="drop-title" id="noti_count">
				You have <span class="notiCount-<?=$id?>"><?=$count?></span> new
				notifications
			</div>
		</li>
		<li class="notification-pad">
			<a href = "#"><div class="mail-contnet message-center-<?=$id?>"></div></a>
		</li>
		<li><a class="text-center nav-link text-center"
			href="<?=Url::toRoute(['/notification'])?>"> <strong>Check all
					notifications ></strong> <i class="fa fa-angle-right"></i>
		</a></li>
	</ul> </div><!-- /.dropdown-messages --></li>
