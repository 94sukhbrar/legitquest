<?php
use app\components\MassAction;
use app\components\TGridView;
use app\models\User;
use yii\helpers\Url;
use yii\widgets\Pjax;
/**
 *
 * @var yii\web\View $this
 * @var yii\data\ActiveDataProvider $dataProvider
 * @var app\modules\notification\models\search\Notification $searchModel
 */

?>
<?php
if (User::isAdmin()) {
    echo MassAction::widget([
        'url' => Url::toRoute([
            'notification/mass'
        ]),
        'grid_id' => 'notification-grid',
        'pjax_grid_id' => 'notification-pjax-grid'
    ]);
}
?>
<div class="table table-responsive">
<?php

Pjax::begin([
    'id' => 'notification-pjax-grid'
]);
?>
    <?php

    echo TGridView::widget([
        'id' => 'notification-grid',
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'tableOptions' => [
            'class' => 'table table-bordered'
        ],
        'columns' => [
            // ['class' => 'yii\grid\SerialColumn','header'=>'<a>S.No.<a/>'],
            [
                'name' => 'check',
                'class' => 'yii\grid\CheckboxColumn',
                'visible' => User::isAdmin()
            ],

            'id',
            'title',
            // 'model_id',
            // 'model_type',
            [
                'attribute' => 'is_read',
                'format' => 'raw',
                'filter' => isset($searchModel) ? $searchModel->getIsReadOptions() : null,
                'value' => function ($data) {
                    return $data->getIsReadBadge();
                }
            ],
            'created_on:datetime',
            [
                'attribute' => 'to_user_id',
                'format' => 'raw',
                'value' => function ($data) {
                    return $data->getRelatedDataLink('to_user_id');
                }
            ],
            [
                'attribute' => 'created_by_id',
                'format' => 'raw',
                'value' => function ($data) {
                    return $data->getRelatedDataLink('created_by_id');
                }
            ],
            [
                'class' => 'app\components\TActionColumn',
                'header' => '<a>Actions</a>',
                'template' => '{view}{delete}',
                'showModal' => true
            ]
        ]
    ]);
    ?>
<?php

Pjax::end();
?>
<div></div>
</div>