<?php
namespace app\modules\file\models\search;

use Yii;
use yii\data\ActiveDataProvider;
use app\models\User;
use app\modules\file\models\File;

/**
 * FilsSearch represents the model behind the search form about `app\models\File`.
 */
class FileSearch extends File
{

	public static function mimeTypesGrouped()
	{
		$mimetypes = [];
		foreach (File::find()->distinct('mimetype')->all() as $file)
			$mimetypes[$file->mimetype] = $file->mimetype;

		return $mimetypes;
	}

	/**
	 * Creates data provider instance with search query applied
	 *
	 * @param array $params
	 *
	 * @return ActiveDataProvider
	 */
	public function search($params)
	{
		$query = File::find();

		// add conditions that should always apply here

		$dataProvider = new ActiveDataProvider([
			'query' => $query,
			'sort' => [
				'defaultOrder' => [
					'created_on' => SORT_DESC
				]
			]
		]);

		$this->load($params);

		$query->andFilterWhere([
			'created_by_id' => User::isAdmin() ? null : Yii::$app->user->id,
			'created_on' => $this->created_on,
			'updated_on' => $this->updated_on,
			'public' => $this->public
		]);

		$query->andFilterWhere([
			'like',
			'filename_user',
			$this->filename_user
		]);
		$query->andFilterWhere([
			'like',
			'filename_path',
			$this->filename_path
		]);
		$query->andFilterWhere([
			'like',
			'mimetype',
			$this->mimetype
		]);

		return $dataProvider;
	}
}
