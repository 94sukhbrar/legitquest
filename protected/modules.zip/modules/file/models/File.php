<?php
namespace app\modules\file\models;

use Imagine\Image\ManipulatorInterface;
use app\components\TActiveRecord;
use app\models\User;
use Yii;
use yii\db\Query;
use yii\helpers\Html;
use yii\helpers\Url;

/**
 * This is the model class for table "file".
 *
 * @property string $id
 */
class File extends TActiveRecord
{

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const TYPE_OFF = 0;

    const TYPE_ON = 1;

    const FILE_TYPE_DEFAULT = 1;

    const EXT_IMAGE = 1;

    const EXT_PDF = 2;

    const EXT_EXCEL = 3;

    const EXT_SOUND = 4;

    const EXT_VIDEO = 5;

    const EXT_ZIP = 6;

    const EXT_POWERPOINT = 7;

    const EXT_OTHER = 8;

    public static function getFileTypeOptions()
    {
        return [
            self::FILE_TYPE_DEFAULT => "Default"
        ];
    }

    public function getFileType()
    {
        $list = self::getFileTypeOptions();
        return isset($list[$this->file_type]) ? $list[$this->file_type] : 'Not Defined';
    }

    public static function getPublicOptions()
    {
        return [
            self::TYPE_ON => "Yes",
            self::TYPE_OFF => "No"
        ];
    }

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "Inactive",
            self::STATE_ACTIVE => "Active"
        ];
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "info",
            self::STATE_ACTIVE => "success"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'label label-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getTypeOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%files}}';
    }

    public function downloadLink($thumb = false)
    {
        if ($thumb) {
            $thumb = [
                'thumb' => true,
                'width' => 300,
                'height' => 300,
                'mode' => ManipulatorInterface::THUMBNAIL_OUTBOUND
            ];
        } else {
            $thumb = [];
        }

        $url = array_merge([
            '/file/file/download',
            'id' => $this->id
        ], $thumb);
        $toUrl = Url::toRoute($url);

        if (! in_array($this->mimetype, [
            "image/jpeg",
            "image/jpg",
            "image/png"
        ])) {
            return Html::a(Yii::t('app', 'Download'), [
                '/file/file/download',
                'id' => $this->id
            ], [
                'class' => 'btn btn-default',
                'data-pjax' => '0'
            ]);
        } else {
            $img = Html::img($toUrl, [
                'class' => '',
                'data-pjax' => '0',
                'width' => '100%',
                'height' => '',
                'alt' => isset($this->seo_alt) ? $this->seo_alt : $this->filename_user,
                'title' => isset($this->seo_title) ? $this->seo_title : $this->filename_user
            ]);

            return Html::a($img . '', $toUrl, [
                'class' => 'list-group-item',
                'data-pjax' => '0',
                'alt' => isset($this->seo_alt) ? $this->seo_alt : $this->filename_user,
                'title' => isset($this->seo_title) ? $this->seo_title : $this->filename_user
            ]);
        }
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {

            if (! isset($this->created_on))
                $this->created_on = date('Y-m-d H:i:s');
            if (! isset($this->updated_on))
                $this->updated_on = date('Y-m-d H:i:s');
            if (! isset($this->created_by_id))
                $this->created_by_id = Yii::$app->user->id;
        } else {
            $this->updated_on = date('Y-m-d H:i:s');
            $this->updated_by_id = Yii::$app->user->id;
        }
        return parent::beforeValidate();
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'public'
                ],
                'default',
                'value' => self::TYPE_OFF
            ],

            [
                [
                    'public',
                    'type_id',
                    'state_id',
                    'file_type'
                ],
                'integer'
            ],
            [
                [
                    'filename_path',
                    'filename_user',
                    'model_type',
                    'model_id',
                    'target_url',
                    'mimetype',
                    'extension'
                ],
                'string'
            ],
            [
                [
                    'created_on',
                    'updated_on',
                    'seo_title',
                    'seo_alt'
                ],
                'safe'
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', '#'),
            'created_by_id' => Yii::t('app', 'created by'),
            'updated_by_id' => Yii::t('app', 'updated by'),
            'created_on' => Yii::t('app', 'created on'),
            'updated_on' => Yii::t('app', 'updated on'),
            'public' => Yii::t('app', 'public'),
            'model_type' => Yii::t('app', 'model_type'),
            'model_id' => Yii::t('app', 'Target'),
            'filename_path' => Yii::t('app', 'filename_path'),
            'filename_user' => Yii::t('app', 'filename_user')
        ];
    }

    public function afterDelete()
    {
        if (Yii::$app->getModule('file')->deletePhysically)
            unlink($this->filename_path);

        parent::afterDelete();
    }

    public function getOwner()
    {
        return $this->hasOne(Yii::$app->getModule('file')->userModelClass, [
            'id' => 'created_by_id'
        ]);
    }

    /**
     * identifierAttribute is necessary e.g.
     * for cases where the target model gets referenced by slug
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTarget()
    {
        $targetClass = $this->model_type;

        $target = new $targetClass();

        $identifier_attribute = 'id';

        if (method_exists($target, 'identifierAttribute'))
            $identifier_attribute = $target->identifierAttribute();

        return $this->hasOne($targetClass::className(), [
            $identifier_attribute => 'model_id'
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ]);
    }

    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'updated_by_id'
        ]);
    }

    public static function getHasManyRelations()
    {
        $relations = [];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        return parent::beforeDelete();
    }

    public function asJson()
    {
        $json = [];
        $json['id'] = $this->id;
        $json['filename_path'] = $this->filename_path;
        $json['filename_user'] = $this->filename_user;
        $json['model_type'] = $this->model_type;
        $json['model_id'] = $this->model_id;
        $json['target_url'] = $this->target_url;
        $json['mimetype'] = $this->mimetype;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;

        return $json;
    }

    public function getUrl($action = 'view', $id = null)
    {
        $params = [
            '/file/' . $this->getControllerID() . '/' . $action
        ];
        if ($id != null)
            $params['id'] = $id;
        else
            $params['id'] = $this->id;
        // add the title parameter to the URL
        if ($this->hasAttribute('title'))
            $params['title'] = $this->title;
        else
            $params['title'] = (string) $this;
        return Yii::$app->getUrlManager()->createAbsoluteUrl($params, true);
    }

    public function filesInfo()
    {
        $query = new Query();
        return $query->select('COUNT(id) AS `count`,format(SUM(size) / (1024 * 1024),1) AS `sum`')
            ->from($this->tableName())
            ->one();
    }

    public function upload($model, $options = [])
    {
        $files_detail = [];
        if (! empty($this->title)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            foreach ($this->title as $file) {
                $real_name = md5(Yii::$app->user->id . time() . $file->baseName . microtime());
                $file_path = UPLOAD_PATH . $real_name . '.' . $file->extension;
                if ($file->saveAs($file_path)) {
                    $class = strtolower((new \ReflectionClass($model))->getShortName());
                    $target = isset($options['targetUrl']) ? $options['targetUrl'] : Url::to([
                        "$class/view",
                        'id' => $model->id
                    ]);
                    $files_detail[] = [
                        'filename_user' => $file->baseName . '.' . $file->extension,
                        'filename_path' => basename($file_path),
                        'public' => isset($options['public']) ? $options['public'] : self::TYPE_ON,
                        'file_type' => isset($options['file_type']) ? $options['file_type'] : self::FILE_TYPE_DEFAULT,
                        'size' => $file->size,
                        'extension' => $file->extension,
                        'mimetype' => finfo_file($finfo, $file_path),
                        'target_url' => $target,
                        'state_id' => File::STATE_ACTIVE,
                        'model_type' => get_class($model),
                        'model_id' => $model->id,
                        'created_by_id' => Yii::$app->user->id,
                        'created_on' => date('Y-m-d H:i:s'),
                        'updated_on' => date('Y-m-d H:i:s')
                    ];
                }
            }
            
            if (! empty($files_detail)) {
                if (! empty($options['delete'])) {
                    $this->deleteOld($model, $options);
                }
                $connection = new Query();
                $connection->createCommand()
                ->batchInsert($this->tableName(), [
                    'filename_user',
                    'filename_path',
                    'public',
                    'file_type',
                    'size',
                    'extension',
                    'mimetype',
                    'target_url',
                    'state_id',
                    'model_type',
                    'model_id',
                    'created_by_id',
                    'created_on',
                    'updated_on'
                ], $files_detail)
                ->execute();
                
                return true;
            }
        }
        return false;
    }
    
    public function deleteOld($model, $options)
    {
        $query = self::find()->where([
            'model_id' => $model->id,
            'model_type' => get_class($model)
        ]);
        
        if (isset($options['file_type'])) {
            $query->andWhere([
                'file_type' => $options['file_type']
            ]);
        } 
        
        foreach ($query->each() as $delete) {
            $file_path = UPLOAD_PATH . $delete->filename_path;
            $delete->delete();
            unlink($file_path);
        }
    }

    public function getSizeInMB()
    {
        if ($this->size < 1048676)
            return number_format($this->size / 1024, 1) . ' ' . Yii::t('app', 'KB');
        else
            return number_format($this->size / 1048576, 1) . ' ' . Yii::t('app', 'MB');
    }

    public function checkExtension()
    {
        $file_parts = $this->extension;

        if (! empty($file_parts)) {
            switch ($file_parts) {
                case 'jpg':
                case 'jpeg':
                case 'png':
                case 'gif':
                    return self::EXT_IMAGE;
                    break;
                case 'mp3':
                case 'ogg':
                case 'amr':
                case 'wav':
                case 'mkv':
                    return self::EXT_SOUND;
                    break;
                case 'mp4':
                case 'webm':
                case 'wma':
                case 'avi':
                case '3gp':
                case 'flv':
                    return self::EXT_VIDEO;
                    break;
                case 'xls':
                case 'xlsb':
                case 'xlsx':
                case 'xlsm':
                case 'odt':
                    return self::EXT_EXCEL;
                    break;
                case 'zip':
                case 'tar':
                case 'rar':
                case 'deb':
                case 'gz':
                    return self::EXT_ZIP;
                    break;
                case 'pdf':
                    return self::EXT_PDF;
                    break;
                case 'ppt':
                    return self::EXT_POWERPOINT;
                    break;
                default:
                    return self::EXT_OTHER;
            }
        } else {
            return self::EXT_OTHER;
        }
    }
    public function isAllowed()
    {
        
        if (User::isAdmin())
            return true;
            
            if ($this instanceof User)
            {
                return ($this->id == Yii::$app->user->id);
            }
            if ($this->hasAttribute('created_by_id'))
            {
                return ($this->created_by_id == Yii::$app->user->id);
            }
            
            if ($this->hasAttribute('user_id'))
            {
                return ($this->user_id == Yii::$app->user->id);
            }
            
            return false;
    }
}
