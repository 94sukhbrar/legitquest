<?php
use app\components\TDetailView;
use yii\helpers\Html;
use app\models\User;
use app\modules\file\models\File;

/* @var $this yii\web\View */
/* @var $model File */

$this->title = $model->filename_user;
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="wrapper">
	<div class=" card ">
		<div class="card-header">
			<h1><?=Html::encode($this->title)?></h1>
		</div>
		<div class="card-body">
			<p class="spacebtn">
				<input action="action" type="button" class="btn btn-primary"
					value="<?=Yii::t('app', 'Back');?>" onclick="history.go(-1);" />
					
 <?php
if (Yii::$app->controller->action->id != "update") {
    echo Html::a(Yii::t('app', 'Update'), [
        '/file/file/update',
        'id' => $model->id
    ], [
        'class' => 'btn btn-success'
    ]);

    echo Html::a(Yii::t('app', 'Remove file'), [
        '/file/file/delete',
        'id' => $model->id
    ], [
        'class' => 'btn btn-danger',
        'data-confirm' => 'Are you sure?'
    ]);
}
?>					
</p>
			<div class="row">
				<div class="col-md-4">
                <?=$model->downloadLink();?>

                <?php
                if ($model->public) {
                    echo Yii::t('app', 'File is public.') . Html::a(Yii::t('app', 'Make protected.'), [
                        '//file/file/protect',
                        'id' => $model->id
                    ], [
                        'class' => 'btn btn-success'
                    ]);
                } else {
                    echo Yii::t('app', 'File is protected.') . Html::a(Yii::t('app', 'Make public.'), [
                        '//file/file/publish',
                        'id' => $model->id
                    ], [
                        'class' => 'btn btn-primary'
                    ]);
                }
                ?>
</div>
				<div class="col-md-8">
            <?php

            echo TDetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'label' => 'Target',
                        'format' => 'html',
                        'value' => function ($data) {
                            if ($data->target) {
                                $identifierAttribute = 'id';

                                if (method_exists($data->target, 'identifierAttribute'))
                                    $identifierAttribute = $data->target->identifierAttribute();

                                return Html::a($data->target->$identifierAttribute, $data->target_url);
                            }
                        }
                    ],
                    'filename_user',
                    [
                        'attribute' => 'model_type',
                        'visible' => User::isAdmin()
                    ],
                    [
                        'attribute' => 'filename_path',
                        'visible' => User::isAdmin()
                    ],

                    [
                        'attribute' => 'public',
                        'value' => $model->public ? Yii::t('app', 'Yes') : Yii::t('app', 'No')
                    ],
                    [
                        'attribute' => 'size',
                        'value' => $model->getSizeInMB()
                    ],

                    'mimetype',
                    'extension',
                    'download_count',
                    [
                        'format' => 'html',
                        'attribute' => 'target_url',
                        'value' => Html::a($model->target_url, $model->target_url)
                    ],
                    'created_on:datetime',
                    'updated_on:datetime',
                    'seo_title',
                    'seo_alt',

                    [
                        'attribute' => 'created_by_id',
                        'format' => 'raw',
                        'value' => $model->getRelatedDataLink('created_by_id')
                    ],
                    [
                        'attribute' => 'updated_by_id',
                        'format' => 'raw',
                        'value' => $model->getRelatedDataLink('created_by_id')
                    ]
                ]
            ]);
            ?>
        </div>
			</div>
		</div>
	</div>
</div>
