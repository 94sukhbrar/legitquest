<?php
use yii\helpers\Html;
use app\components\TActiveForm;
use app\models\User;

/* @var $this yii\web\View */
/* @var $model app\modules\file\models\File */
/* @var $form yii\widgets\ActiveForm */
?>
<header class="card-header">
    <?=strtoupper(Yii::$app->controller->action->id);?>
</header>

<div class="card-body">
    <?php
    $form = TActiveForm::begin([
        'id' => 'banner-form'
    ]);

    ?>

	
	
	<div class="row">
		<div class="col-md-4">
	 		<?=$form->field($model, 'public')->dropDownList($model->getPublicOptions())->label('Is Public')?>
	 	</div>
		<div class="col-md-4">
	 		<?=$form->field($model, 'seo_title')->textInput(['maxlength' => 255])?>
	 	</div>
		<div class="col-md-4">
	 		<?=$form->field($model, 'seo_alt')->textInput(['maxlength' => 255])?>
	 	</div>
	</div>
	<div class="row">
		<div class="col-md-12 bottom-admin-button btn-space-bottom text-right">
        <?=Html::submitButton($model->isNewRecord ? Yii::t('app', 'Save') : Yii::t('app', 'Update'), ['id' => 'banner-form-submit','class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])?>
    </div>
	</div>
</div>
<?php

TActiveForm::end();
?>

</div>
<div class="card-body">
<?=$this->render('view', ['model' => $model])?>
</div>
