<?php
use app\modules\file\models\search\FileSearch;
use yii\grid\GridView;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\Pjax;
use app\modules\file\models\File;
use app\components\MassAction;
use app\models\User;

/* @var $this yii\web\View */
/* @var $searchModel app\models\User */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $filesInfo File */

$this->title = Yii::t('app', 'Files');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="wrapper">
	<div class="files-index">
		<div class="card">
			<div class="translator-index card-body">
				<h1><?=Html::encode($this->title)?></h1>
			</div>
		</div>
		<div class="card">

			<div class="card-body">
				<div class="alert alert-success"> <?php

    if ($filesInfo['count'])
        echo Yii::t('app', 'So far, {count} files of {sum} MB have been uploaded', [
            'count' => $filesInfo['count'],
            'sum' => $filesInfo['sum']
        ]);
    ?></div>
    <div class="fa-br"></div>
				<br>
				
				<?php
    if (User::isAdmin())
        echo MassAction::widget([
            'url' => Url::toRoute([
                '/file/file/mass'
            ]),
            'grid_id' => 'file-grid',
            'pjax_grid_id' => 'file-pjax-grid'
        ]);
    ?>
<div class="table table-responsive">
	 <?php
Pjax::begin([
    'id' => 'file-pjax-grid'
]);

?>
                
                    <?php

                    echo GridView::widget([
                        'id' => 'file-grid',
                        'dataProvider' => $dataProvider,
                        'filterModel' => $searchModel,
                        'columns' => [
                            [
                                'name' => 'check',
                                'class' => 'yii\grid\CheckboxColumn',
                                'visible' => User::isAdmin()
                            ],
                            [
                                'class' => 'yii\grid\SerialColumn'
                            ],

                            [
                                'filter' => false,
                                'format' => 'html',
                                'attribute' => 'model_id',
                                'value' => function ($data) {
                                    if ($data->target) {
                                        $identifierAttribute = 'id';
                                        if (method_exists($data->target, 'identifierAttribute'))
                                            $identifierAttribute = $data->target->identifierAttribute();
                                        return Html::a($data->target->$identifierAttribute, $data->target_url);
                                    }
                                }
                            ],
                            'filename_user',
                            [
                                'filter' => FileSearch::mimeTypesGrouped(),
                                'attribute' => 'mimetype'
                            ],
                            [
                                'filter' => [
                                    0 => Yii::t('app', 'No'),
                                    1 => Yii::t('app', 'Yes')
                                ],
                                'attribute' => 'public',
                                'format' => 'html',
                                'value' => function ($model) {
                                    if ($model->public) {
                                        return Yii::t('app', 'File is public.') . Html::a(Yii::t('app', 'Make protected.'), [
                                            '//file/file/protect',
                                            'id' => $model->id
                                        ], [
                                            'class' => 'btn btn-default'
                                        ]);
                                    } else {
                                        return Yii::t('app', 'File is protected.') . Html::a(Yii::t('app', 'Make public.'), [
                                            '//file/file/publish',
                                            'id' => $model->id
                                        ], [
                                            'class' => 'btn btn-default'
                                        ]);
                                    }
                                }
                            ],
                            [
                                'format' => 'raw',
                                'header' => Yii::t('app', 'Download'),
                                'value' => function ($data) {
                                    return $data->downloadLink();
                                }
                            ],
                            [
                                'attribute' => 'size',
                                'value' => function ($model) {
                                    return $model->getSizeInMB();
                                },
                                'headerOptions' => [
                                    'class' => 'auto-fit'
                                ],
                                'filterOptions' => [
                                    'class' => 'auto-fit'
                                ],
                                'contentOptions' => [
                                    'class' => 'auto-fit ltr center'
                                ]
                            ],
                            'created_on:datetime',
                            [
                                'attribute' => 'created_by_id',
                                'format' => 'raw',
                                'value' => function ($data) {
                                    return $data->getRelatedDataLink('created_by_id');
                                }
                            ],
                            [
                                'class' => 'app\components\TActionColumn',
                                'showModal' => \Yii::$app->params['useCrudModals'] = false,
                                'template' => '{view} {delete}',
                                'urlCreator' => function ($action, $model, $key, $index) {
                                    return Url::to([
                                        'file/' . $action,
                                        'id' => $model->id
                                    ]);
                                }
                            ]
                        ]
                    ]);
                    ?>
                    <?php

                    Pjax::end();
                    ?>
                </div>
		</div>
	</div>
</div>