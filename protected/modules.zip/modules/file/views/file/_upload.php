<?php
use kartik\file\FileInput;
use yii\helpers\Url;
use yii\base\InvalidConfigException;
use app\modules\file\models\File;
use Faker\UniqueGenerator;

/* @var $model File  */
/* @var $pluginOptions FileInput */
/* @var $options FileInput */
/* @var $pluginEvents FileInput */
/* @var $target_url FileInput */
/* @var $id UniqueGenerator */

if ($model->isNewRecord) {
    throw new InvalidConfigException("You cannot use this widget while creating new model.");
}
if (! isset($pluginOptions))
    $pluginOptions = [];

$pluginOptions = array_merge($pluginOptions, [
    'showUpload' => true,
    'uploadUrl' => Url::to(Yii::$app->getModule('file')->uploadUrl),
    'uploadExtraData' => [
        'model_type' => $model::className(),
        'type_id' => isset($options['type_id']) ? $options['type_id'] : 0,
        'attribute' => isset($_POST['attribute']) ? $_POST['attribute'] : '',
        'model_id' => method_exists($model, 'identifierAttribute') ? $model->{$model->identifierAttribute()} : $model->id,
        'target_url' => isset($target_url) ? $target_url : null,
        'options' => isset($options['multiple']) ? $options['multiple'] : false
    ]
]);

echo FileInput::widget([
    'id' => isset($id) ? $id : 'file-module',
    'name' => 'files',
    'options' => isset($options) ? $options : [],
    'pluginOptions' => $pluginOptions,
    'pluginEvents' => isset($pluginEvents) ? $pluginEvents : []
   
]);
