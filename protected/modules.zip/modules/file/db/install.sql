-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------
-- -------------------------------------------

-- -------------------------------------------

-- TABLE `tbl_files`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_files`;
CREATE TABLE `tbl_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text DEFAULT NULL,
  `model_id` text NOT NULL,
  `model_type` text NOT NULL,
  `target_url` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `filename_user` text NOT NULL,
  `filename_path` text NOT NULL,
  `extension` varchar(255) NOT NULL,
  `public` int(11) NOT NULL,
  `size` bigint(20) NOT NULL,
  `download_count` bigint(20) DEFAULT '0',
  `file_type` int(11) DEFAULT '1',
  `mimetype` varchar(255) NOT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_alt` varchar(255) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `updated_by_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_files_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_files_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  KEY `fk_files_updated_by_id` (`updated_by_id`),
  CONSTRAINT `fk_files_updated_by_id` FOREIGN KEY (`updated_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- -- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
-- --------------------------------------------------------------------------------------
-- END BACKUP
-- -------------------------------------------
