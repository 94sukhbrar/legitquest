<?php
namespace app\modules\file;

use app\components\TModule;
use app\components\TController;

/**
 * file module definition class
 */
class Module extends TModule
{

    public $version = '1.0';

    /**
     *
     * @inheritdoc
     */
    public $controllerNamespace = 'app\modules\file\controllers';

    public $defaultRoute = 'file\file\index';

    /**
     *
     * @var boolean Should the file also be deleted physically on removal ?
     */
    public $deletePhysically = false;

    /**
     *
     * @var string Url to upload files.
     */
    public $uploadUrl = [
        '/file/file/upload'
    ];

    public $uploadPath = null;

    /**
     *
     * @var string The class of the User Model inside the application this module is attached to
     */
    public $userModelClass = 'app\models\User';

    /** @var array The rules to be used in URL management. */
    public $urlRules = [
        'file/update/<id>' => 'file/file/update',
        'file/delete/<id>' => 'file/file/delete',
        'file/<id>' => 'file/file/view',
        'file/index' => 'file/file/index',
        'file/create' => 'file/file/create',
        'file/manager/file/<id>' => 'file/manager/file'
    ];

    public static function dbFile()
    {
        return __DIR__ . '/db/install.sql';
    }

    /**
     *
     * @inheritdoc
     */
    public function init()
    {

        /**
         *
         * @var string Physical directory where the upload files should be saved. Make sure the folder exists.
         *      by default the files get saved outside of the web/ directory for security reasons. If you want the files to
         *      be public accessible, you can change the path here.
         */
        if (! $this->uploadPath)
            $this->uploadPath = UPLOAD_PATH;

        parent::init();
    }

    public static function subNav()
    {
        if (method_exists("\app\components\WebUser", 'getIsAdminMode'))
            if (\Yii::$app->user->isAdminMode) {
                return self::adminSubNav();
            }
        return TController::addMenu(\Yii::t('app', 'Files'), '//file\file\index', 'list-alt', (Module::isManager()));
    }

    public static function adminSubNav()
    {
        return TController::addMenu(\Yii::t('app', 'Files'), '//file\file\index', 'list-alt', (Module::isManager()));
    }
}
