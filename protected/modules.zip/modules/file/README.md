# Files Module

Files can be uploaded and linked to an ActiveRecord Model.
Contains only one table 'files' where everything is stored.
The files are uploaded into an protected folder by default.

## Configuration

Add following lines to your main configuration file:

```php
$config['modules']['files'] = [
    'class' => 'app\modules\files\Module'
];
```

## Integration in your application:

Attach the hasFilesBehavior onto every ActiveRecord model that you want to attach files to:

```php
use \app\modules\files\behaviors\HasFilesBehavior;

    public function behaviors()
    {
        return [
                HasFilesBehavior::className(),
                ];
    }
```

You can access every uploaded file that is attached to the Active Record model depending on the current
logged in user via:

```php
$model->files;
```

#You can render an upload widget that attaches every uploaded file automatically to the model by using AJAX:

```php
use yii\helpers\Url;
<?php
	if (\Yii::$app->hasModule('file') && ! $model->isNewRecord)
	{
		$path = MODULE_PATH.'file/views/file/_upload';
		echo $this->render($path, [
			'model' => $model,
			'options' => [
				'multiple' => true
			], // optional
 			'pluginOptions' => [
		        'maxFileSize' => 2000
		      ],
			'uploadExtraData' => [
				'public' => true
			], // uploaded files are automatically public (default is: protected). optional.
			'target_url' => Url::to([
				'user/view',
				'id' => $model->id
			]) // optional
		]);
	}

	?>
```


```php
use app\modules\files\models\File;

$model = File::findOne(57);
echo File::downloadLink();
```

to display a "Download file" button in the view file.



##if ($model->isNewRecord())

 ```	
 use app\modules\files\models\File;
 
 $fileModel = new File();
    $fileModel->title = UploadedFile::getInstances($fileModel, 'title');
    $result = $fileModel->upload($model);
    if ($result) {
         Yii::$app->session->setFlash('success', Yii::t('app', 'File uploaded.'));
                 }
           return $this->render('index', [
            'model' => $yourModel,
            'fileModel' => $fileModel
        ]);
            
 ```
        
##Image GalleryViewer

###Using files relation

```
<?php

echo LightGalleryWidget::widget([
    'files' => $model->files,
    'options' => [
        'mode' => 'lg-zoom-in-big',
        'download' => true,
        'zoom' => true,
        'share' => true
    ]
]);
?>

```

###Using items (Custom :- Not Recommended)

```
<?php
 if (! empty($this->files)) {

            foreach ($this->files as $file) {
                $url = Url::toRoute([
                    '/file/file/download',
                    'id' => $file->id
                ]);
                $thumbUrl = Url::toRoute([
                    '/file/file/thumbnail',
                    'filename' => $file->filename_path
                ]);

                $this->items[] = [
                    'thumb' => $thumbUrl,
                    'src' => $url
                ];
            }
        }
        
echo LightGalleryWidget::widget([
    'items' => $items,
    'options' => [
        'mode' => 'lg-zoom-in-big',
        'download' => true,
        'zoom' => true,
        'share' => true
    ]
]);
?>
    
```

##Document Viewer
This widget will help you with all type of documents rendering for your HTML pages

```
<?= DocumentViewerWidget::widget([
    'model' => $model
]);
?>
```

#Add in your composer for Document Viewer

```
"lesha724/yii2-document-viewer": "*"
"perminder-klair/yii2-videojs": "dev-master"
"yii2assets/yii2-pdfjs": ">=1.0"
```

## License

Files TOXSL Technologies 
