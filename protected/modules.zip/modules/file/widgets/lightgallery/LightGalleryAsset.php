<?php
namespace app\modules\file\widgets\lightgallery;

use yii\web\AssetBundle;

class LightGalleryAsset extends AssetBundle
{

	public $sourcePath = '@app/modules/file/widgets/lightgallery';

	public $css = [
		'dist/css/lg-transitions.min.css',
		'dist/css/lightgallery.min.css'
	];

	public $js = [
		'dist/js/lightgallery.min.js',
		'dist/js/lg-autoplay.min.js',
		'dist/js/lg-fullscreen.min.js',
		'dist/js/lg-share.min.js',
		'dist/js/lg-thumbnail.min.js',
		'dist/js/lg-video.min.js',
		'dist/js/lg-zoom.min.js'
	];

	public $depends = [
		'yii\web\JqueryAsset'
	];
}