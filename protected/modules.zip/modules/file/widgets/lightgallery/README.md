jQuery lightgallery for Yii2
============

Usage
-----

Once the extension is installed, simply use it in your code by  :

```php
<?php
    use app\modules\file\widgets\lightgallery\LightGalleryWidget;
    $items = [];
    if (! empty($model->files))
{
	
	foreach ($model->files as $file)
	{
		$url = Url::toRoute([
			'/file/file/download',
			'id' => $file->id
		]);
		$thumbUrl = Url::toRoute([
			'/file/file/thumbnail',
			'filename' => $file->filename_path
		]);

		$items[] = [
			'thumb' => $thumbUrl,
			'src' => $url
		];
	}
}
    echo LightGalleryWidget::widget([
        'items' => $items,
        'options' => [
            'mode' => 'lg-zoom-in-big',
            'download' => false,
            'zoom' => false,
            'share' => false
        ]
    ]);
    
    
    
?>

```

## More information about gallery [here](http://sachinchoolur.github.io/lightGallery/).

