<?php
namespace app\modules\file\widgets;

use app\modules\file\assets\ViewerAsset;
use yii\base\Widget;
use app\modules\file\models\File;
use yii\data\ActiveDataProvider;
use yii\base\InvalidConfigException;

class DocumentViewerWidget extends Widget
{

    /**
     *
     * @var array|object the data model whose details are to be displayed. This can be a [[Model]] instance,
     *      an associative array, an object that implements [[Arrayable]] interface or simply an object with defined
     *      public accessible non-static properties.
     */
    public $model;

    public $options;

    /**
     * Initializes the detail view.
     * This method will initialize required property values.
     */
    public function init()
    {
        parent::init();

        if ($this->model === null) {
            throw new InvalidConfigException('Please specify the "model" property.');
        }
        $this->getView()->registerAssetBundle(ViewerAsset::class);
    }

    public function run()
    {
        $this->renderHtml();
    }

    public function renderHtml()
    {
        $query = File::find()->where([
            'model_id' => $this->model->id,
            'model_type' => get_class($this->model)
        ]);

        if (! empty($this->options['file_type'])) {
            $query = $query->andWhere([
                'file_type' => $this->options['file_type']
            ]);
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => ! empty($this->options['defaultOrder']) ? $this->options['defaultOrder'] : SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => ! empty($this->options['pageSize']) ? $this->options['pageSize'] : 5
            ]
        ]);

        echo $this->render('viewerList', [
            'options' => $this->options,
            'dataProvider' => $dataProvider
        ]);
    }
}
