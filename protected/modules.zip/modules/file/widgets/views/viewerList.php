<?php
use app\models\User;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use app\modules\file\models\File;
/* @var $dataProvider File */
?>
<section class="section popup-modal">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="row">
                  <div class="col-md-12">
                  <div class="card-body">
                     <!-- Tab panes -->
                     <div class="tab-content">
                        <div class="tab-pane active" id="home">
                        
                     
                              <?php
                            Pjax::begin([
                                'id' => 'my-listviews-id',
                                'enablePushState' => true, // to disable push state
                                'enableReplaceState' => true
                            ]);
                            ?>
                              <?php
                            if (! User::isGuest()) {

                                echo ListView::widget([
                                    'id' => 'my-listviews-id',
                                    'dataProvider' => $dataProvider,
                                    'itemView' => '_viewer',
                                    'layout' => "{items}{pager}",
                                    'emptyText' => '',
                                    'itemOptions' => [
                                        'class' => 'col-md-3'
                                    ],
                                    'options' => [
                                        'tag' => 'div',
                                        'class' => 'row mt-30'
                                    ]
                                ]);
                            }
                            ?>   
                              <?php
                            Pjax::end();
                            ?>  
                          
                        </div>
                     </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- /.row -->
   <!-- /.container-fluid -->
</section>
<script>
  

</script>