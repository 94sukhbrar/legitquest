<?php
use yii\helpers\Url;
use yii\helpers\Html;
use app\modules\file\models\File;
/* @var $model File */
/* @var $this File */
$extension = $model->extension;
?>


<div title="<?=$model->filename_user?>"
	class="file-grid position-relative">
	<div class="file-detail">
		<h4><?=$model->getFileType()?></h4>

	</div>
	<div class="img-wrapper text-center">
		<?php
$url = Url::toRoute([
    '/file/file/download',
    'id' => $model->id
]);
$checkExt = $model->checkExtension();

if ($checkExt == File::EXT_PDF) {
    ?>
      <?php
    $pdfUrl = $this->theme->getUrl('assets/images/pdf.png');
    echo "<div class='icon-images'><img src='$pdfUrl'/></div>";
    ?>
<?php
} elseif ($checkExt == File::EXT_SOUND) {
    $mp3Url = $this->theme->getUrl('assets/images/mp3.png');
    echo "<div class='icon-images small-height'><img src='$mp3Url'/></div>";
    echo '<audio width="100%" height="100%" controls style=" width: 100% !important;">
  <source src="' . $url . '" type="audio/ogg">
  <source src="' . $url . '" type="audio/mpeg">
  Your browser does not support the Audio tag.
</audio>';
} elseif ($checkExt == File::EXT_EXCEL) {
    $excelUrl = $this->theme->getUrl('assets/images/excel.png');
    echo "<div class='icon-images'><img src='$excelUrl'/></div>";
} elseif ($checkExt == File::EXT_ZIP) {
    $zipUrl = $this->theme->getUrl('assets/images/zip.png');
    echo "<div class='icon-images'><img src='$zipUrl'/></div>";
} elseif ($checkExt == File::EXT_IMAGE) {

    echo '<div class="icon-images"><img  height = "100%" src="' . Url::toRoute([
        '/file/file/thumbnail',
        'filename' => $model->filename_path,
        'width' => 667,
        'height' => 350
    ]) . '"/></div>';
} elseif ($checkExt == File::EXT_VIDEO) {
    echo '<div class="icon-images"><video width="100%" height="100%" controls>
  <source src="' . $url . '" type="video/mp4">
  <source src="' . $url . '" type="video/ogg">
  Your browser does not support the video tag.
</video></div>';
} elseif ($checkExt == File::EXT_POWERPOINT) {
    $pptUrl = $this->theme->getUrl('assets/images/ppt.png');
    echo "<div class='icon-images'><img src='$pptUrl'/></div>";
} else {
    $fileUrl = $this->theme->getUrl('assets/images/other.png');
    echo "<div class='icon-images'><img src='$fileUrl'/></div>";
}

?>
	</div>
	<div class="file-detail">
		<a class="btn btn-sm add-btn btn-primary" data-pjax="0"
			href="<?=Url::toRoute(['/file/file/download','id' => $model->id])?>">

			Download </a>
				<?php

    if (in_array($extension, [
        'doc',
        'docx',
        'odt',
        'jpg',
        'png',
        'jpeg',
        'pdf',
        'mp4',
        'avi',
        'flv',
        '3gp',
        'wma',
        'ppt',
        'pptx',
        'xls',
        'xlsx',
        'gif'
    ])) {
        ?>
					<a data-name="<?=$model->description?>" data-ext="<?=$extension?>"
			data-url="<?=$url?>" data-toggle="modal"
			data-target="#myModal_<?=$model->id?>"
			class="btn btn-sm add-btn btn-primary">Open </a> <?php
    }
    ?>
				 <a data-method="POST"
			data-confirm="Are you sure you want to delete this item?"
			class="btn btn-sm add-btn btn-danger pull-right"
			href="<?=Url::toRoute(['/file/file/delete','id' => $model->id])?>">Delete</a>
	</div>
	<div class="file-detail">
		<p class="m-n"><?=$model->filename_user?><span class="pull-right"><?=$extension?></span>
		</p>

	</div>

</div>

<!-- Modal -->
<div id="myModal_<?=$model->id?>" class="modal fade" role="dialog">
	<div class="modal-dialog modal-md">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"><?=$model->description?></h4>
			</div>
			<div class="modal-body">
        <?php

        if (in_array($extension, [
            'odt'
        ])) {
            echo \lesha724\documentviewer\ViewerJsDocumentViewer::widget([
                'url' => $url,
                'width' => '100%',
                'height' => '100%'
            ]);
        } else if (in_array($extension, [
            'doc',
            'docx'
        ])) {
            echo '<iframe style=" width: 100%; height: 500px;" src="https://docs.google.com/viewer?url=' . $_SERVER['HTTP_HOST'] . $url . '&embedded=true"></iframe>';
        } else if (in_array($extension, [
            'jpg',
            'png',
            'jpeg'
        ])) {
            $opt = [
                'class' => 'img-responsive',
                'id' => 'cabinet_file'
            ];
            echo Html::img($url, $opt);
        } else if (in_array($extension, [
            'pdf'
        ])) {
           
            // echo \yii2assets\pdfjs\PdfJs::widget([
            // 'url' => $url,
            // 'width' => '100%',
            // // 'height' => '100%',
            // 'buttons' => [
            // 'presentationMode' => false,
            // 'openFile' => false,
            // 'print' => false,
            // 'download' => true,
            // 'viewBookmark' => false,
            // 'secondaryToolbarToggle' => false
            // ]
            // ]);
        } else if (in_array($extension, [
            'mp4',
            'avi',
            'flv',
            '3gp',
            'wma'
        ])) {
            echo \kato\VideojsWidget::widget([
                'options' => [
                    'class' => 'video-js vjs-default-skin vjs-big-play-centered',
                    'poster' => 'http://video-js.zencoder.com/oceans-clip.png',
                    'controls' => true,
                    'preload' => 'auto',
                    'width' => '100%',
                    'height' => '400',
                    'data-setup' => '{ "plugins" : { "resolutionSelector" : { "default_res" : "720" } } }'
                ],
                'tags' => [
                    'source' => [
                        [
                            'src' => $url,
                            'type' => 'video/mp4',
                            'data-res' => '360'
                        ],
                        [
                            'src' => $url,
                            'type' => 'video/mp4',
                            'data-res' => '720'
                        ]
                    ]
                ],
                'multipleResolutions' => true
            ]);
        } else if (in_array($extension, [
            'ppt',
            'pptx'
        ])) {

            echo '<iframe src="https://view.officeapps.live.com/op/view.aspx?src=' . Yii::$app->urlManager->createAbsoluteUrl('file/files?file=' . $model->filename_user) . '" width="100%" height="600px" frameborder="0"></iframe>';
        } else if (in_array($extension, [
            'xls',
            'xlsx'
        ])) {
            echo '<iframe src="http://view.officeapps.live.com/op/view.aspx?src=' . Yii::$app->urlManager->createAbsoluteUrl('file/files?file=' . $model->filename_user) . '" width="100%" height="600px" frameborder="0"></iframe>';
        } else {
            echo "Nothing Found";
        }
        ?>
     
      </div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><?=$extension?></button>
			</div>
		</div>

	</div>
</div>