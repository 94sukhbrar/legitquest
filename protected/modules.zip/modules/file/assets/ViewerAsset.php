<?php
namespace app\modules\file\assets;

use yii\web\AssetBundle;

class ViewerAsset extends AssetBundle
{

    /**
     *
     * @inheritdoc
     */
    public $sourcePath = '@app/modules/file/assets/src';

    /**
     *
     * @inheritdoc
     */
    public $css = [
        'css/style-file.css'
    ];

    public $js = [
        'js/custom.js'
    ];

    /* Do not need in b4 version */
    /*
     * public $depends = [
     * 'yii\web\YiiAsset',
     * 'yii\bootstrap\BootstrapAsset',
     * 'yii\bootstrap\BootstrapPluginAsset'
     * ];
     */
}
