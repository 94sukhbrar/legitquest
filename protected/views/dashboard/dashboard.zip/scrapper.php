<div class="card">
    <div class="card-body">
        <?= $this->render ( '_form', [ 'model' => $model ] )?>
    </div>
</div>



