<?php
use yii\helpers\Html;
?>  

<?=$model->name;?> 
<?=$model->age;?> 
<?=$model->mobile;?>
